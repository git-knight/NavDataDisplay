﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NavDataDisplay
{
    public class NavDataEntry
    {
        public DateTime Time { get; set; }
        public double Lat { get; set; }
        public double Lon { get; set; }
        public double Atm { get; set; }
        public double Speed { get; set; }
        public double Angle { get; set; }

        public NavDataEntry() { }
        public NavDataEntry(string dataEntry)
        {
            if (dataEntry[dataEntry.IndexOf("AZ") - 1] != ';')
                dataEntry = dataEntry.Insert(dataEntry.IndexOf("AZ"), ";");

            var parts = dataEntry.Split(';');

            var time = long.Parse(dataEntry.Substring(5, 13));
            Time = new DateTime(621355968000000000 + time * 10 * 1000, DateTimeKind.Utc);
            Lat = float.Parse(parts[1].Substring(2), CultureInfo.InvariantCulture.NumberFormat);
            Lon = float.Parse(parts[2].Substring(2), CultureInfo.InvariantCulture.NumberFormat);
            Atm = float.Parse(parts[3].Substring(2), CultureInfo.InvariantCulture.NumberFormat);
            Speed = float.Parse(parts[4].Substring(2), CultureInfo.InvariantCulture.NumberFormat);
            Angle = float.Parse(parts[5].Substring(4), CultureInfo.InvariantCulture.NumberFormat) + 180;
        }

        public double GetValueByGraphNumber(int num) => num switch
        {
            0 => this.Atm,
            1 => Angle,
            _ => Atm
        };

        public override string ToString()
        {
            return Speed.ToString("#.##") + " " + Time.ToString("G");
        }
    }
}
